export interface TweeterRequest {
  readonly token: string;
  readonly userAlias: string;
}

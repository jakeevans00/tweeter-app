export interface AuthTokenDto {
  readonly token: string;
  readonly timestamp: number;
}
